<p align="left"> 
<a href="#"><img title="Made in Bangladesh" src="https://img.shields.io/badge/MADE%20IN-BANGLADESH-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center"><a href="#"><img title="b11" src="https://user-images.githubusercontent.com/64999484/89707580-4f2c2580-d991-11ea-8960-3c6f9e46765f.png"></a>
<p align="center"><a href="https://github.com/bootolvau"><img title="Author" src="https://img.shields.io/badge/Author-Botol--Vau-red.svg?style=for-the-badge&logo=github"></a></p>
<p align="center"><a href="https://github.com/botolvau/followers"><img title="Followers" src="https://img.shields.io/github/followers/botolmehedi?color=blue&style=flat-square"></a> <a href="https://www.youtube.com/mastertrick1"><img title="Youtube" src="https://img.shields.io/badge/YOUTUBE-%40mastertrick1-red?style=flat-square&logo=youtube"></a> <a href="https://www.facebook.com/groups/231747098048450"><img title="Messenger" src="https://img.shields.io/badge/Chat-Messenger-blue?style=flat-square&logo=messenger"></a></p>

<h1 align="center">b11 v1.0</h1>
<p align="center">      FACEBOOK ACCOUNT CLONER TOOL FOR TERMUX USERS</p>

## ***About b11***:

b11 is a python based script. You can use this tool for clone normal facebook account. This tool works on any Android devices.

## Installation :
```
$ pkg update && pkg upgrade
$ pkg install python
$ pkg install python2
$ pkg install git
$ pkg install pip
$ pkg install pip2
$ pip2 install requests
$ pip2 install mechanize
$ git clone https://github.com/botolvau/b11
```

## Tools Run :
```
$ ls && cd b11 && ls
$ python2 b11.py
```

* Tools Username / Passwords : https://www.facebook.com/groups/231747098048450/permalink/275501883672971/


## ***Follow Me***

* Youtube : [Subscribe Now](https://www.youtube.com/MasterTrick1)
* Website : [Visit Now](http://www.mastertrick.design)
* Page : [Follow Us](https://www.facebook.com/TeamVVirus)
* Group : [Join Us](https://www.facebook.com/groups/231747098048450)
* Telegram : [Join Now](https://t.me/mastertrick2)
* Instagram : [Follow Me](https://www.instagram.com/MehtanOfficial)
* Twitter : [Follow Me](https://www.twitter.com/botolbaba)
* GitHub : [Follow Me](https://www.github.com/Botolvau)

### Warning

***Don't try to edit or modify this tool. This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
